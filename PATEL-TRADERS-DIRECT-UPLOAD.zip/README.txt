PATEL TRADERS - Netlify Direct Upload

यह तैयार static website है। इसमें npm install, build या ZIP extract करने की जरूरत नहीं है अगर Netlify आपके upload screen पर ZIP स्वीकार करता है.

Netlify पर Deploy manually / Netlify Drop में इस ZIP को upload करें. ZIP के अंदर index.html सीधे root में है.

ध्यान दें: यह शुरुआती catalog/preview है। Supabase Admin Login, database, live stock, online payment और WhatsApp checkout अभी कनेक्ट नहीं हैं। उन्हें बाद में सुरक्षित तरीके से जोड़ना होगा.
